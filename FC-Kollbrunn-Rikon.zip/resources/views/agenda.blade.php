@extends('layouts.app')
@section('content')
    <section id="agenda">
        <agenda></agenda>
    </section>
@endsection