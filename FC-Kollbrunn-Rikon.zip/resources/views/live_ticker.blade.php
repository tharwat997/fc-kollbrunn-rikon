@extends('layouts.app')
@section('content')
    <section id="tickerPage">
        <ticker></ticker>
    </section>
@endsection
