@extends('layouts.app')
@section('content')
    <section id="contactUs">
        <contact></contact>
    </section>
@endsection