<section id="sponsors-section">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1 id="sponsors-section-title">Our Sponsors</h1>
            </div>
        </div>
        <div class="sponsors" id="platinum-sponsors">
            <div class="mb-3">
                <h2 class="sponsors-title">Platinum Sponsors</h2>
            </div>
           <div class="row d-flex  align-items-center">
               <div class="col-sm-3">
                   <img class="img-fluid" src="{{asset('images/sponsors/adidas.svg')}}" />
               </div>
               <div class="col-sm-3">
                   <img class="img-fluid" src="{{asset('images/sponsors/jeep.svg')}}" />
               </div>

           </div>
        </div>
        <div class="sponsors " id="gold-sponsors">
            <div class="mb-3">
                <h2 class="sponsors-title">Gold Sponsors</h2>
            </div>
            <div class="row d-flex  align-items-center">
                <div class="col-sm-3">
                    <img class="img-fluid" src="{{asset('images/sponsors/adidas.svg')}}" />
                </div>
                <div class="col-sm-3">
                    <img class="img-fluid" src="{{asset('images/sponsors/jeep.svg')}}" />
                </div>
                <div class="col-sm-3">
                    <img class="img-fluid" src="{{asset('images/sponsors/adidas.svg')}}" />
                </div>
            </div>
        </div>
        <div class="sponsors" id="silver-sponsors">
            <div class="mb-3">
                <h2 class="sponsors-title">Silver Sponsors</h2>
            </div>
            <div class="row d-flex align-items-center">
                <div class="col-sm-3">
                    <img class="img-fluid" src="{{asset('images/sponsors/adidas.svg')}}" />
                </div>
                <div class="col-sm-3">
                    <img class="img-fluid" src="{{asset('images/sponsors/jeep.svg')}}" />
                </div>
                <div class="col-sm-3">
                    <img class="img-fluid" src="{{asset('images/sponsors/adidas.svg')}}" />
                </div>
                <div class="col-sm-3">
                    <img class="img-fluid" src="{{asset('images/sponsors/jeep.svg')}}" />
                </div>
            </div>
        </div>
    </div>
</section>