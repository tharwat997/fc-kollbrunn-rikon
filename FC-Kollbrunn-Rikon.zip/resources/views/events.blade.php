@extends('layouts.app')
@section('content')
    <section id="events">
        <div class="container">
            <div class="row">
                <b-card>
                    <div class="card-title">
                        <h1>Events</h1>
                        <h5>Some text here</h5>
                    </div>
                        <div class="row">
                            <div class="col-3 col-md-4 col-sm-6 col-xs-12 mb-4 eventCard">
                                <b-card  img-src="https://placeimg.com/250/250/any"  img-alt="Image" img-top>
                                    <div class="eventCardTop">
                                        <div class="d-flex justify-content-between align-items-center eventDateLocationContainer">
                                            <div class="eventDate">8 March, 2019</div>
                                            <div class="eventLocation d-flex align-items-center">
                                                <v-icon name="map-marker-alt">
                                                </v-icon>
                                                <span class="ml-1">Zurich</span>
                                            </div>
                                        </div>
                                        <div class="mb-2 eventName">Event Name</div>
                                        <div class="eventDescription">
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos eveniet non numquam sit. Aperiam autem consequatur, doloremque ducimus esse excepturi ipsum itaque laudantium magni quidem saepe temporibus velit? Consequuntur, mollitia!
                                        </div>
                                    </div>
                                    <div class="eventCardBottom">
                                        <a href="#" class="btn btn-primary">Volunteer</a>
                                        <a href="#" class="btn btn-primary">Participate</a>
                                    </div>
                                </b-card>
                            </div>
                            <div class="col-3 col-md-4 col-sm-6 col-xs-12 mb-4 eventCard">
                                <b-card  img-src="https://placeimg.com/250/250/any"  img-alt="Image" img-top>
                                    <div class="eventCardTop">
                                        <div class="d-flex justify-content-between align-items-center eventDateLocationContainer">
                                            <div class="eventDate">8 March, 2019</div>
                                            <div class="eventLocation d-flex align-items-center">
                                                <v-icon name="map-marker-alt">
                                                </v-icon>
                                                <span class="ml-1">Zurich</span>
                                            </div>
                                        </div>
                                        <div class="mb-2 eventName">Event Name</div>
                                        <div class="eventDescription">
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos eveniet non numquam sit. Aperiam autem consequatur, doloremque ducimus esse excepturi ipsum itaque laudantium magni quidem saepe temporibus velit? Consequuntur, mollitia!
                                        </div>
                                    </div>
                                    <div class="eventCardBottom">
                                        <a href="#" class="btn btn-primary">Volunteer</a>
                                        <a href="#" class="btn btn-primary">Participate</a>
                                    </div>
                                </b-card>
                            </div>
                            <div class="col-3 col-md-4 col-sm-6 col-xs-12 mb-4 eventCard">
                                <b-card  img-src="https://placeimg.com/250/250/any"  img-alt="Image" img-top>
                                    <div class="eventCardTop">
                                        <div class="d-flex justify-content-between align-items-center eventDateLocationContainer">
                                            <div class="eventDate">8 March, 2019</div>
                                            <div class="eventLocation d-flex align-items-center">
                                                <v-icon name="map-marker-alt">
                                                </v-icon>
                                                <span class="ml-1">Zurich</span>
                                            </div>
                                        </div>
                                        <div class="mb-2 eventName">Event Name</div>
                                        <div class="eventDescription">
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos eveniet non numquam sit. Aperiam autem consequatur, doloremque ducimus esse excepturi ipsum itaque laudantium magni quidem saepe temporibus velit? Consequuntur, mollitia!
                                        </div>
                                    </div>
                                    <div class="eventCardBottom">
                                        <a href="#" class="btn btn-primary">Volunteer</a>
                                        <a href="#" class="btn btn-primary">Participate</a>
                                    </div>
                                </b-card>
                            </div>
                            <div class="col-3 col-md-4 col-sm-6 col-xs-12 mb-4 eventCard">
                                <b-card  img-src="https://placeimg.com/250/250/any"  img-alt="Image" img-top>
                                    <div class="eventCardTop">
                                        <div class="d-flex justify-content-between align-items-center eventDateLocationContainer">
                                            <div class="eventDate">8 March, 2019</div>
                                            <div class="eventLocation d-flex align-items-center">
                                                <v-icon name="map-marker-alt">
                                                </v-icon>
                                                <span class="ml-1">Zurich</span>
                                            </div>
                                        </div>
                                        <div class="mb-2 eventName">Event Name</div>
                                        <div class="eventDescription">
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos eveniet non numquam sit. Aperiam autem consequatur, doloremque ducimus esse excepturi ipsum itaque laudantium magni quidem saepe temporibus velit? Consequuntur, mollitia!
                                        </div>
                                    </div>
                                    <div class="eventCardBottom">
                                        <a href="#" class="btn btn-primary">Volunteer</a>
                                        <a href="#" class="btn btn-primary">Participate</a>
                                    </div>
                                </b-card>
                            </div>
                            <div class="col-3 col-md-4 col-sm-6 col-xs-12 mb-4 eventCard">
                                <b-card  img-src="https://placeimg.com/250/250/any"  img-alt="Image" img-top>
                                    <div class="eventCardTop">
                                        <div class="d-flex justify-content-between align-items-center eventDateLocationContainer">
                                            <div class="eventDate">8 March, 2019</div>
                                            <div class="eventLocation d-flex align-items-center">
                                                <v-icon name="map-marker-alt">
                                                </v-icon>
                                                <span class="ml-1">Zurich</span>
                                            </div>
                                        </div>
                                        <div class="mb-2 eventName">Event Name</div>
                                        <div class="eventDescription">
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos eveniet non numquam sit. Aperiam autem consequatur, doloremque ducimus esse excepturi ipsum itaque laudantium magni quidem saepe temporibus velit? Consequuntur, mollitia!
                                        </div>
                                    </div>
                                    <div class="eventCardBottom">
                                        <a href="#" class="btn btn-primary">Volunteer</a>
                                        <a href="#" class="btn btn-primary">Participate</a>
                                    </div>
                                </b-card>
                            </div>
                        </div>
                </b-card>
            </div>
        </div>
    </section>
@endsection