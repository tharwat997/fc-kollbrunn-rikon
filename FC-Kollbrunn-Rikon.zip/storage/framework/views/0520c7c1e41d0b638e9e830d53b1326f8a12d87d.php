<?php /* C:\xampp\htdocs\FC-Kollbrunn-Rikon\resources\views/admin/agenda/manage_agenda.blade.php */ ?>
<?php $__env->startSection('css'); ?>
    <link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="page-header row no-gutters py-4">
        <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
            <span class="text-uppercase page-subtitle">Agenda</span>
            <h4 class="page-title">Add event</h4>
        </div>
    </div>
    <!-- End Page Header -->
    <div class="row">
        <div class="col-12">
            <div class="card  mb-4">
                <div class="card-header border-bottom">
                    <h6 class="m-0">Manage agenda events</h6>
                </div>
                <div class="card-body">
                    <?php if(Session::has('message')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?></p>
                    <?php endif; ?>
                    <div class="d-none">
                        <?php $__currentLoopData = $agendaEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form id="form-<?php echo e($event->id); ?>" action="<?php echo e(route('agenda_events_update')); ?>" type="GET">
                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                        <div class="overflow-scroll">
                            <table id="manageAgendaEventsTable" class="display" style="width:100%">
                                <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Start Date Time</th>
                                    <th>End Date Time</th>
                                    <th>Action</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $agendaEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><input form="form-<?php echo e($event->id); ?>" type="text" class="form-control" name="title" value="<?php echo e($event->title); ?>"></td>
                                        <td><input form="form-<?php echo e($event->id); ?>" type="datetime-local"  class="form-control"  name="start_date" value="<?php echo e($event->start_date); ?>"></td>
                                        <td><input form="form-<?php echo e($event->id); ?>" type="datetime-local"  class="form-control"  name="end_date" value="<?php echo e($event->end_date); ?>"></td>
                                        <td>
                                            <select form="form-<?php echo e($event->id); ?>" name="action" class="form-control" id="action">
                                                <option value="update">update</option>
                                                <option value="delete">delete</option>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="hidden" form="form-<?php echo e($event->id); ?>" name="eventId" value="<?php echo e($event->id); ?>">
                                            <button form="form-<?php echo e($event->id); ?>" type="submit" class="btn btn-warning">Confirm</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready( function () {
            $('#manageAgendaEventsTable').DataTable({
                "columnDefs": [
                    {"className": "dt-center", "targets": "_all"}
                ],
                responsive: true
            });

        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>