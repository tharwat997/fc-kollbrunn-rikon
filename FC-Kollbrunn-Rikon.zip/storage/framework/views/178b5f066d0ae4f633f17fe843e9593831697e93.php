<?php /* C:\xampp\htdocs\FC-Kollbrunn-Rikon\resources\views/team.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <section id="teamSection">
        <?php if(@isset($firstTeam)): ?>
            <team team-name="First Team">
                <img alt="team" class="w-100 img-fluid" src="<?php echo e(asset('images/teams/first_team/firstTeam1.jpg')); ?>" />
            </team>
        <?php elseif(@isset($juniorC)): ?>
            <team team-name="Junior C">
                <img alt="team" class="w-100 img-fluid" src="<?php echo e(asset('images/teams/first_team/firstTeam1.jpg')); ?>" />
            </team>
        <?php elseif(@isset($juniorD)): ?>
            <team team-name="Junior D">
                <img alt="team" class="w-100 img-fluid" src="<?php echo e(asset('images/teams/first_team/firstTeam1.jpg')); ?>" />
            </team>
        <?php elseif(@isset($juniorE)): ?>
            <team team-name="Junior E">
                <img alt="team" class="w-100 img-fluid" src="<?php echo e(asset('images/teams/first_team/firstTeam1.jpg')); ?>" />
            </team>
        <?php elseif(@isset($juniorF)): ?>
            <team team-name="Junior F">
                <img alt="team" class="w-100 img-fluid" src="<?php echo e(asset('images/teams/first_team/firstTeam1.jpg')); ?>" />
            </team>
        <?php elseif(@isset($boardOfDirectors)): ?>
            <team :board-of-directors="true" team-name="Board of directors">
                <img alt="team" class="w-100 img-fluid" src="<?php echo e(asset('images/teams/first_team/firstTeam1.jpg')); ?>" />
            </team>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>