<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EventsController extends Controller
{
    public function index(){
        return view('events');
    }

    public function events(){

    }

    public function eventsCreate(){
        return view('admin.events.create_event');
    }

    public function store(){

    }

    public function eventsManage(){
        return view('admin.events.manage_events');
    }

    public function update(){

    }
}
